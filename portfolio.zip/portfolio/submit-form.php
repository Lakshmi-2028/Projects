<?php
$name = $_POST['name'];
$email = $_POST['email'];
$message = $_POST['message'];

// Simple server-side validation
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo "Email is not valid.";
    exit;
}

$recipient = "your-email@example.com"; // change this to your email
$subject = "Message from $name";
$body = "You have received a new message from your website contact form.\n\n";
$body .= "Here are the details:\n";
$body .= "Name: $name\nEmail: $email\nMessage: $message\n";

$headers = "From: $email\n";
$headers .= "Reply-To: $email";

mail($recipient, $subject, $body, $headers);

echo "Thank you for your message. I will get back to you soon.";
?>
